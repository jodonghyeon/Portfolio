#version 450 core

layout(location = 0) in vec2 vTextureCoordinates;

layout(location = 0) out vec4 fFragClr;

uniform sampler2D uTex2d;
uniform vec4 uColor;

void main()
{
    fFragClr = texture(uTex2d, vTextureCoordinates) * uColor;
}
